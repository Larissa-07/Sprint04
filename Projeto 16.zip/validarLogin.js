function validarLogin() {
    const cpfRegex = /^\d{3}\.\d{3}\.\d{3}\-\d{2}$/;

    const cpf = document.getElementById("cpf").value;

    if (!cpfRegex.test(cpf)) {
        alert("CPF inválido. Insira um novo CPF.");
        return false;
    }

    return true
}